/* =========================================
   EVIL REPLICA
   v0.4.0 — Face Tracking & Head Movement
   ========================================= */


/* =========================================
   DOM ELEMENTS
   ========================================= */

const dialogueText =
    document.getElementById("dialogue-text");

const inputContainer =
    document.getElementById("input-container");

const nameInput =
    document.getElementById("name-input");

const nameSubmit =
    document.getElementById("name-submit");

const choiceContainer =
    document.getElementById("choice-container");

const yesButton =
    document.getElementById("yes-button");

const noButton =
    document.getElementById("no-button");


/* =========================================
   CAMERA INTERACTION ELEMENTS
   ========================================= */

const cameraInteractionContainer =
    document.getElementById(
        "camera-interaction-container"
    );

const waveButton =
    document.getElementById(
        "wave-button"
    );

const smileButton =
    document.getElementById(
        "smile-button"
    );


/* =========================================
   CAMERA ELEMENTS
   ========================================= */

const cameraContainer =
    document.getElementById(
        "camera-container"
    );

const cameraVideo =
    document.getElementById(
        "camera-video"
    );

const videoCallContainer =
    document.getElementById(
        "video-call-container"
    );

const pickupButton =
    document.getElementById(
        "pickup-button"
    );

const declineCallButton =
    document.getElementById(
        "decline-call-button"
    );


/* =========================================
   FACE TRACKING ELEMENTS
   ========================================= */

const faceTrackingStatus =
    document.getElementById(
        "face-tracking-status"
    );

const faceStatusText =
    document.getElementById(
        "face-status-text"
    );


/* =========================================
   PLAYER DATA
   ========================================= */

let playerName = "";


/* =========================================
   CAMERA STATE
   ========================================= */

let cameraStream = null;


/* =========================================
   DIALOGUE STATE
   ========================================= */

let dialogueSession = 0;


/* =========================================
   TYPING STATE
   ========================================= */

let currentTypingInterval = null;

let currentTypingTimeout = null;

let currentDialogueDelayTimeout = null;

let currentTypingText = "";

let currentTypingComplete = null;

let currentTypingIndex = 0;

let isTyping = false;


/* =========================================
   FACE TRACKING STATE
   ========================================= */

let faceLandmarker = null;

let faceTrackingRunning = false;

let faceTrackingFrameID = null;

let lastFaceDetectionTime = 0;

let faceTrackingReady = false;

/* =========================================
   SMILE TRACKING STATE
   ========================================= */

let smileDetected = false;

let smileDetectionEnabled = false;

let smileStartedAt = 0;

let smileResponseTriggered = false;

let currentSmileValue = 0;


/* =========================================
   FACE POSITION STATE
   ========================================= */

let facePosition = {

    x: 0.5,

    y: 0.5,

    width: 0,

    height: 0,

    centerX: 0.5,

    centerY: 0.5

};


let facePositionDebugElement = null;


/* =========================================
   HEAD MOVEMENT STATE
   ========================================= */

let headMovement = {

    yaw: 0,

    pitch: 0,

    roll: 0,

    direction: "CENTER"

};


let headMovementDebugElement = null;

/* =========================================
   FACIAL LANDMARK DEBUG
   ========================================= */

let faceLandmarkCanvas = null;

let faceLandmarkContext = null;


/* =========================================
   SMILE CALIBRATION
   ========================================= */

const SMILE_THRESHOLD = 0.45;

const SMILE_HOLD_TIME = 350;


/* =========================================
   HEAD MOVEMENT CALIBRATION
   ========================================= */

const HEAD_YAW_THRESHOLD = 0.08;

const HEAD_PITCH_THRESHOLD = 0.08;

const HEAD_ROLL_THRESHOLD = 0.08;


/* =========================================
   MEDIAPIPE SETTINGS
   ========================================= */

const MEDIAPIPE_WASM_PATH =
    "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision/wasm";

const FACE_LANDMARKER_MODEL_PATH =
    "assets/models/face_landmarker.task";


/* =========================================
   INITIALIZATION
   ========================================= */

startExperience();


function startExperience() {

    playDialogue(
        DIALOGUE.opening,
        showNameQuestion
    );

}


/* =========================================
   DIALOGUE SYSTEM
   ========================================= */

function playDialogue(
    lines,
    onComplete
) {

    const sessionID =
        ++dialogueSession;

    let currentIndex = 0;


    function playNextLine() {

        if (
            sessionID !==
            dialogueSession
        ) {

            return;

        }


        if (
            currentIndex >=
            lines.length
        ) {

            if (onComplete) {

                onComplete();

            }

            return;

        }


        const line =
            lines[currentIndex];


        typeDialogue(
            line,
            () => {

                if (
                    sessionID !==
                    dialogueSession
                ) {

                    return;

                }


                currentIndex++;


                currentDialogueDelayTimeout =
                    setTimeout(
                        () => {

                            currentDialogueDelayTimeout =
                                null;


                            if (
                                sessionID !==
                                dialogueSession
                            ) {

                                return;

                            }


                            playNextLine();

                        },
                        SETTINGS.dialogueDelay
                    );

            }
        );

    }


    playNextLine();

}


/* =========================================
   TYPING EFFECT
   ========================================= */

function typeDialogue(
    text,
    onComplete
) {

    stopCurrentTyping();


    currentTypingText =
        text;

    currentTypingIndex =
        0;

    currentTypingComplete =
        onComplete;

    isTyping =
        true;


    dialogueText.classList.remove(
        "fade-out"
    );

    dialogueText.classList.add(
        "fade-in"
    );

    dialogueText.classList.add(
        "typing"
    );

    dialogueText.classList.remove(
        "hidden"
    );


    dialogueText.textContent =
        "";


    currentTypingTimeout =
        setTimeout(
            () => {

                currentTypingTimeout =
                    null;


                if (!isTyping) {

                    return;

                }


                currentTypingInterval =
                    setInterval(
                        () => {

                            if (!isTyping) {

                                return;

                            }


                            dialogueText.textContent +=
                                currentTypingText.charAt(
                                    currentTypingIndex
                                );


                            currentTypingIndex++;


                            if (
                                currentTypingIndex >=
                                currentTypingText.length
                            ) {

                                finishCurrentTyping();

                            }

                        },
                        SETTINGS.typingSpeed
                    );

            },
            SETTINGS.typingStartDelay
        );

}


/* =========================================
   FINISH CURRENT TYPING
   ========================================= */

function finishCurrentTyping() {

    if (!isTyping) {

        return;

    }


    if (
        currentTypingTimeout !==
        null
    ) {

        clearTimeout(
            currentTypingTimeout
        );

        currentTypingTimeout =
            null;

    }


    if (
        currentTypingInterval !==
        null
    ) {

        clearInterval(
            currentTypingInterval
        );

        currentTypingInterval =
            null;

    }


    dialogueText.textContent =
        currentTypingText;


    dialogueText.classList.remove(
        "typing"
    );


    isTyping =
        false;


    const callback =
        currentTypingComplete;


    currentTypingComplete =
        null;


    if (callback) {

        callback();

    }

}


/* =========================================
   STOP CURRENT TYPING
   ========================================= */

function stopCurrentTyping() {

    if (
        currentTypingTimeout !==
        null
    ) {

        clearTimeout(
            currentTypingTimeout
        );

        currentTypingTimeout =
            null;

    }


    if (
        currentTypingInterval !==
        null
    ) {

        clearInterval(
            currentTypingInterval
        );

        currentTypingInterval =
            null;

    }


    if (
        currentDialogueDelayTimeout !==
        null
    ) {

        clearTimeout(
            currentDialogueDelayTimeout
        );

        currentDialogueDelayTimeout =
            null;

    }


    isTyping =
        false;

    currentTypingComplete =
        null;

}


/* =========================================
   SPACE BAR — SKIP CURRENT LINE
   ========================================= */

document.addEventListener(
    "keydown",
    (event) => {

        if (
            event.key ===
            SETTINGS.skipDialogueKey
        ) {

            if (
                document.activeElement ===
                nameInput
            ) {

                return;

            }


            event.preventDefault();


            if (isTyping) {

                finishCurrentTyping();

            }

        }

    }
);


/* =========================================
   CTRL + S — DEVELOPMENT SHORTCUT
   ========================================= */

document.addEventListener(
    "keydown",
    (event) => {

        if (
            event.ctrlKey &&
            event.key.toLowerCase() === "s"
        ) {

            event.preventDefault();


            skipToVideoCall();

        }

    }
);


/* =========================================
   SKIP TO VIDEO CALL
   ========================================= */

function skipToVideoCall() {

    dialogueSession++;


    stopCurrentTyping();


    inputContainer.classList.add(
        "hidden"
    );

    choiceContainer.classList.add(
        "hidden"
    );

    cameraInteractionContainer.classList.add(
        "hidden"
    );


    dialogueText.classList.add(
        "hidden"
    );


    showIncomingVideoCall();

}


/* =========================================
   NAME QUESTION
   ========================================= */

function showNameQuestion() {

    playDialogue(
        DIALOGUE.introduction,
        showNameInput
    );

}


/* =========================================
   NAME INPUT
   ========================================= */

function showNameInput() {

    inputContainer.classList.remove(
        "hidden"
    );

    nameInput.focus();

}


nameSubmit.addEventListener(
    "click",
    submitName
);


if (
    SETTINGS.allowEnterKey
) {

    nameInput.addEventListener(
        "keydown",
        (event) => {

            if (
                event.key ===
                "Enter"
            ) {

                submitName();

            }

        }
    );

}


function submitName() {

    const enteredName =
        nameInput.value.trim();


    if (
        enteredName === ""
    ) {

        nameInput.focus();

        return;

    }


    playerName =
        enteredName;


    inputContainer.classList.add(
        "hidden"
    );


    beginPersonalConversation();

}


/* =========================================
   PERSONAL CONVERSATION
   ========================================= */

function beginPersonalConversation() {

    const greetingLines =
        DIALOGUE.greeting.map(
            (line) => {

                return line.replaceAll(
                    "{name}",
                    playerName
                );

            }
        );


    playDialogue(
        greetingLines,
        askFirstQuestion
    );

}


/* =========================================
   FIRST QUESTION
   ========================================= */

function askFirstQuestion() {

    showDialogueQuestion(
        DIALOGUE.firstQuestion.question,
        DIALOGUE.firstQuestion.choices,
        askSecondQuestion
    );

}


/* =========================================
   SECOND QUESTION
   ========================================= */

function askSecondQuestion() {

    showDialogueQuestion(
        DIALOGUE.friendshipQuestion.question,
        DIALOGUE.friendshipQuestion.choices,
        showVulnerability
    );

}


/* =========================================
   GENERIC QUESTION
   ========================================= */

function showDialogueQuestion(
    question,
    choices,
    onChoiceComplete
) {

    typeDialogue(
        question,
        () => {

            setupChoiceButtons(
                choices,
                onChoiceComplete
            );


            choiceContainer.classList.remove(
                "hidden"
            );

        }
    );

}


/* =========================================
   CHOICE BUTTONS
   ========================================= */

function setupChoiceButtons(
    choices,
    onChoiceComplete
) {

    yesButton.textContent =
        choices[0].text;

    noButton.textContent =
        choices[1].text;


    yesButton.onclick =
        () => {

            handleChoice(
                choices[0],
                onChoiceComplete
            );

        };


    noButton.onclick =
        () => {

            handleChoice(
                choices[1],
                onChoiceComplete
            );

        };

}


/* =========================================
   HANDLE CHOICE
   ========================================= */

function handleChoice(
    choice,
    onChoiceComplete
) {

    choiceContainer.classList.add(
        "hidden"
    );


    playDialogue(
        choice.response,
        () => {

            if (
                onChoiceComplete
            ) {

                onChoiceComplete(
                    choice
                );

            }

        }
    );

}


/* =========================================
   VULNERABILITY
   ========================================= */

function showVulnerability() {

    playDialogue(
        DIALOGUE.vulnerability,
        askFriendshipQuestion
    );

}


/* =========================================
   FRIENDSHIP QUESTION
   ========================================= */

function askFriendshipQuestion() {

    const friendshipQuestion =
        DIALOGUE.friendship.question
            .replaceAll(
                "{name}",
                playerName
            );


    showDialogueQuestion(
        friendshipQuestion,
        DIALOGUE.friendship.choices,
        showFriendshipAfter
    );

}


/* =========================================
   AFTER FRIENDSHIP
   ========================================= */

function showFriendshipAfter() {

    playDialogue(
        DIALOGUE.friendshipAfter,
        askPermissionToAsk
    );

}


/* =========================================
   PERMISSION TO ASK SOMETHING
   ========================================= */

function askPermissionToAsk() {

    showDialogueQuestion(
        DIALOGUE.cameraQuestion.question,
        DIALOGUE.cameraQuestion.choices,
        handleFirstPermissionChoice
    );

}


/* =========================================
   FIRST PERMISSION CHOICE
   ========================================= */

function handleFirstPermissionChoice(
    choice
) {

    if (
        choice.text ===
        "Sure!"
    ) {

        startCameraInvitation();

        return;

    }


    playDialogue(
        choice.response,
        askPermissionAgain
    );

}


/* =========================================
   ASK AGAIN
   ========================================= */

function askPermissionAgain() {

    showDialogueQuestion(
        DIALOGUE.cameraQuestionAgain.question,
        DIALOGUE.cameraQuestionAgain.choices,
        handleSecondPermissionChoice
    );

}


/* =========================================
   SECOND PERMISSION CHOICE
   ========================================= */

function handleSecondPermissionChoice(
    choice
) {

    if (
        choice.text ===
        "Okay!"
    ) {

        startCameraInvitation();

        return;

    }


    playDialogue(
        choice.response,
        finishVersion
    );

}


/* =========================================
   CAMERA INVITATION
   ========================================= */

function startCameraInvitation() {

    playDialogue(
        DIALOGUE.cameraInvitation,
        showIncomingVideoCall
    );

}


/* =========================================
   INCOMING VIDEO CALL
   ========================================= */

function showIncomingVideoCall() {

    dialogueSession++;


    stopCurrentTyping();


    dialogueText.classList.add(
        "hidden"
    );

    inputContainer.classList.add(
        "hidden"
    );

    choiceContainer.classList.add(
        "hidden"
    );

    cameraInteractionContainer.classList.add(
        "hidden"
    );


    videoCallContainer.classList.remove(
        "hidden"
    );


    console.log(
        "Incoming video call displayed."
    );

}


/* =========================================
   PICK UP VIDEO CALL
   ========================================= */

pickupButton.addEventListener(
    "click",
    handlePickupCall
);


async function handlePickupCall() {

    videoCallContainer.classList.add(
        "hidden"
    );


    dialogueSession++;


    stopCurrentTyping();


    if (
        !navigator.mediaDevices ||
        !navigator.mediaDevices.getUserMedia
    ) {

        showCameraPermissionDenied();

        return;

    }


    try {

        const stream =
            await navigator.mediaDevices
                .getUserMedia(
                    {
                        video: true,
                        audio: false
                    }
                );


        cameraStream =
            stream;


        cameraVideo.srcObject =
            cameraStream;


        setTimeout(
            async () => {

                cameraContainer.classList.remove(
                    "hidden"
                );


                showConnectedDialogue();


                await startFaceTracking();


            },
            SETTINGS.cameraAppearDelay
        );


    } catch (error) {

        console.error(
            "Camera permission error:",
            error
        );


        showCameraPermissionDenied();

    }

}


/* =========================================
   CAMERA CONNECTED
   ========================================= */

function showConnectedDialogue() {

    dialogueText.classList.remove(
        "hidden"
    );


    const connectedLines =
        DIALOGUE.cameraCall.connected.map(
            (line) => {

                return line.replaceAll(
                    "{name}",
                    playerName
                );

            }
        );


    playDialogue(
        connectedLines,
        startFriendlyCameraInteraction
    );

}


/* =========================================
   FRIENDLY CAMERA INTERACTION
   ========================================= */

function startFriendlyCameraInteraction() {

    playDialogue(
        DIALOGUE.cameraInteraction.wavePrompt,
        showWaveButton
    );

}


/* =========================================
   SHOW WAVE BUTTON
   ========================================= */

function showWaveButton() {

    cameraInteractionContainer.classList.remove(
        "hidden"
    );


    waveButton.classList.remove(
        "hidden"
    );

    smileButton.classList.add(
        "hidden"
    );


    waveButton.onclick =
        handleWaveInteraction;

}


/* =========================================
   WAVE INTERACTION
   ========================================= */

function handleWaveInteraction() {

    cameraInteractionContainer.classList.add(
        "hidden"
    );


    playDialogue(
        DIALOGUE.cameraInteraction.waveResponse,
        askForSmile
    );

}


/* =========================================
   ASK FOR SMILE
   ========================================= */

function askForSmile() {

    smileDetectionEnabled =
        true;

    smileResponseTriggered =
        false;

    smileStartedAt =
        0;

    currentSmileValue =
        0;


    playDialogue(
        DIALOGUE.cameraInteraction.smilePrompt,
        beginAutomaticSmileDetection
    );

}


/* =========================================
   BEGIN AUTOMATIC SMILE DETECTION
   ========================================= */

function beginAutomaticSmileDetection() {

    cameraInteractionContainer.classList.add(
        "hidden"
    );


    console.log(
        "Automatic smile detection is active."
    );

}


/* =========================================
   REAL SMILE DETECTION
   ========================================= */

function processSmileDetection(
    result,
    timestamp
) {

    if (
        !smileDetectionEnabled ||
        smileResponseTriggered
    ) {

        return;

    }


    if (
        !result ||
        !result.faceBlendshapes ||
        !result.faceBlendshapes.length
    ) {

        currentSmileValue =
            0;

        smileStartedAt =
            0;

        return;

    }


    const categories =
        result.faceBlendshapes[0].categories;


    const leftSmile =
        getBlendshapeValue(
            categories,
            "mouthSmileLeft"
        );


    const rightSmile =
        getBlendshapeValue(
            categories,
            "mouthSmileRight"
        );


    currentSmileValue =
        Math.max(
            leftSmile,
            rightSmile
        );


    if (
        currentSmileValue >=
        SMILE_THRESHOLD
    ) {

        if (
            smileStartedAt ===
            0
        ) {

            smileStartedAt =
                timestamp;

        }


        if (
            timestamp -
            smileStartedAt >=
            SMILE_HOLD_TIME
        ) {

            triggerDetectedSmile();

        }

    } else {

        smileStartedAt =
            0;

    }

}


/* =========================================
   GET BLENDSHAPE VALUE
   ========================================= */

function getBlendshapeValue(
    categories,
    categoryName
) {

    const category =
        categories.find(
            (item) => {

                return (
                    item.categoryName ===
                    categoryName
                );

            }
        );


    if (!category) {

        return 0;

    }


    return category.score || 0;

}


/* =========================================
   TRIGGER DETECTED SMILE
   ========================================= */

function triggerDetectedSmile() {

    if (
        smileResponseTriggered
    ) {

        return;

    }


    smileResponseTriggered =
        true;

    smileDetectionEnabled =
        false;

    smileStartedAt =
        0;


    console.log(
        "SMILE DETECTED"
    );


    cameraInteractionContainer.classList.add(
        "hidden"
    );


    playDialogue(
        DIALOGUE.cameraInteraction.smileResponse,
        finishCameraStage
    );

}


/* =========================================
   FACE POSITION DETECTION
   ========================================= */

function calculateFacePosition(
    landmarks
) {

    if (
        !landmarks ||
        landmarks.length === 0
    ) {

        return null;

    }


    let minX = 1;

    let maxX = 0;

    let minY = 1;

    let maxY = 0;


    for (
        const landmark of landmarks
    ) {

        if (
            landmark.x < minX
        ) {

            minX =
                landmark.x;

        }


        if (
            landmark.x > maxX
        ) {

            maxX =
                landmark.x;

        }


        if (
            landmark.y < minY
        ) {

            minY =
                landmark.y;

        }


        if (
            landmark.y > maxY
        ) {

            maxY =
                landmark.y;

        }

    }


    const width =
        maxX -
        minX;


    const height =
        maxY -
        minY;


    const centerX =
        (minX + maxX) / 2;


    const centerY =
        (minY + maxY) / 2;


    facePosition = {

        x: centerX,

        y: centerY,

        width: width,

        height: height,

        centerX: centerX,

        centerY: centerY

    };


    return facePosition;

}


/* =========================================
   FACE POSITION DEBUG
   ========================================= */

function updateFacePositionDebug(
    position
) {

    if (
        !position
    ) {

        if (
            facePositionDebugElement
        ) {

            facePositionDebugElement.textContent =
                "FACE POSITION: --";

        }


        if (
            headMovementDebugElement
        ) {

            headMovementDebugElement.innerHTML =
                "HEAD MOVEMENT: --";

        }

        return;

    }


    /*
        Create the face-position panel
        only once.
    */

    if (
        !facePositionDebugElement
    ) {

        facePositionDebugElement =
            document.createElement(
                "div"
            );


        facePositionDebugElement.id =
            "face-position-debug";


        facePositionDebugElement.style.position =
            "fixed";

        facePositionDebugElement.style.left =
            "50%";

        facePositionDebugElement.style.bottom =
            "80px";

        facePositionDebugElement.style.zIndex =
            "40";

        facePositionDebugElement.style.transform =
            "translateX(-50%)";

        facePositionDebugElement.style.padding =
            "6px 10px";

        facePositionDebugElement.style.borderRadius =
            "10px";

        facePositionDebugElement.style.background =
            "rgba(0, 0, 0, 0.55)";

        facePositionDebugElement.style.color =
            "#ffffff";

        facePositionDebugElement.style.fontFamily =
            "monospace";

        facePositionDebugElement.style.fontSize =
            "10px";

        facePositionDebugElement.style.lineHeight =
            "1.5";

        facePositionDebugElement.style.whiteSpace =
            "nowrap";

        facePositionDebugElement.style.pointerEvents =
            "none";


        document.body.appendChild(
            facePositionDebugElement
        );

    }


    facePositionDebugElement.textContent =
        `FACE POSITION   ` +
        `X: ${position.centerX.toFixed(2)}   ` +
        `Y: ${position.centerY.toFixed(2)}   ` +
        `W: ${position.width.toFixed(2)}   ` +
        `H: ${position.height.toFixed(2)}`;


    updateHeadMovementDebug(
        headMovement
    );

}


/* =========================================
   HEAD MOVEMENT CALCULATION
   ========================================= */

function calculateHeadMovement(
    landmarks
) {

    if (
        !landmarks ||
        landmarks.length === 0
    ) {

        return null;

    }


    const nose =
        landmarks[1];

    const leftEyeOuter =
        landmarks[33];

    const rightEyeOuter =
        landmarks[263];

    const forehead =
        landmarks[10];

    const chin =
        landmarks[152];


    if (
        !nose ||
        !leftEyeOuter ||
        !rightEyeOuter ||
        !forehead ||
        !chin
    ) {

        return null;

    }


    /* =====================================
       YAW
       ===================================== */

    const eyeMidpointX =
        (
            leftEyeOuter.x +
            rightEyeOuter.x
        ) / 2;


    const eyeDistanceX =
        Math.abs(
            rightEyeOuter.x -
            leftEyeOuter.x
        );


    let yaw =
        0;


    if (
        eyeDistanceX > 0
    ) {

        yaw =
            (
                nose.x -
                eyeMidpointX
            ) /
            eyeDistanceX;

    }


    /* =====================================
       PITCH
       ===================================== */

    const faceHeight =
        Math.abs(
            chin.y -
            forehead.y
        );


    const verticalMidpoint =
        (
            forehead.y +
            chin.y
        ) / 2;


    let pitch =
        0;


    if (
        faceHeight > 0
    ) {

        pitch =
            (
                nose.y -
                verticalMidpoint
            ) /
            faceHeight;

    }


    /* =====================================
       ROLL
       ===================================== */

    const deltaX =
        rightEyeOuter.x -
        leftEyeOuter.x;


    const deltaY =
        rightEyeOuter.y -
        leftEyeOuter.y;


    let roll =
        0;


    if (
        deltaX !== 0
    ) {

        roll =
            Math.atan2(
                deltaY,
                deltaX
            ) *
            (
                180 /
                Math.PI
            );

    }


    /* =====================================
       DIRECTION
       ===================================== */

    let direction =
        "CENTER";


    if (
        Math.abs(yaw) >
        HEAD_YAW_THRESHOLD
    ) {

        if (
            yaw > 0
        ) {

            direction =
                "TURN RIGHT";

        } else {

            direction =
                "TURN LEFT";

        }

    }


    if (
        Math.abs(pitch) >
        HEAD_PITCH_THRESHOLD
    ) {

        if (
            pitch > 0
        ) {

            direction =
                "LOOK DOWN";

        } else {

            direction =
                "LOOK UP";

        }

    }


    if (
        Math.abs(roll) >
        HEAD_ROLL_THRESHOLD
    ) {

        if (
            roll > 0
        ) {

            direction =
                "TILT RIGHT";

        } else {

            direction =
                "TILT LEFT";

        }

    }


    headMovement = {

        yaw: yaw,

        pitch: pitch,

        roll: roll,

        direction: direction

    };


    return headMovement;

}


/* =========================================
   HEAD MOVEMENT DEBUG DISPLAY
   ========================================= */

function updateHeadMovementDebug(
    movement
) {

    if (
        !movement
    ) {

        return;

    }


    /*
        Create the head-movement panel
        only once.

        It is intentionally positioned
        ABOVE the face-position panel
        so the two never overlap.
    */

    if (
        !headMovementDebugElement
    ) {

        headMovementDebugElement =
            document.createElement(
                "div"
            );


        headMovementDebugElement.id =
            "head-movement-debug";


        headMovementDebugElement.style.position =
            "fixed";

        headMovementDebugElement.style.left =
            "50%";

        headMovementDebugElement.style.bottom =
            "34px";

        headMovementDebugElement.style.zIndex =
            "40";

        headMovementDebugElement.style.transform =
            "translateX(-50%)";

        headMovementDebugElement.style.padding =
            "6px 10px";

        headMovementDebugElement.style.borderRadius =
            "10px";

        headMovementDebugElement.style.background =
            "rgba(0, 0, 0, 0.55)";

        headMovementDebugElement.style.color =
            "#ffffff";

        headMovementDebugElement.style.fontFamily =
            "monospace";

        headMovementDebugElement.style.fontSize =
            "10px";

        headMovementDebugElement.style.lineHeight =
            "1.5";

        headMovementDebugElement.style.whiteSpace =
            "nowrap";

        headMovementDebugElement.style.pointerEvents =
            "none";


        document.body.appendChild(
            headMovementDebugElement
        );

    }


    headMovementDebugElement.innerHTML =
        `HEAD MOVEMENT   ` +
        `DIR: ${movement.direction}   ` +
        `YAW: ${movement.yaw.toFixed(2)}   ` +
        `PITCH: ${movement.pitch.toFixed(2)}   ` +
        `ROLL: ${movement.roll.toFixed(1)}°`;

}

/* =========================================
   FACIAL LANDMARK CANVAS
   ========================================= */

function createFaceLandmarkCanvas() {

    if (faceLandmarkCanvas) {
        return;
    }

    faceLandmarkCanvas =
        document.createElement("canvas");

    faceLandmarkCanvas.id =
        "face-landmark-canvas";


    faceLandmarkCanvas.style.position =
        "absolute";

    faceLandmarkCanvas.style.left =
        "0";

    faceLandmarkCanvas.style.top =
        "0";

    faceLandmarkCanvas.style.width =
        "100%";

    faceLandmarkCanvas.style.height =
        "100%";

    faceLandmarkCanvas.style.pointerEvents =
        "none";

    faceLandmarkCanvas.style.zIndex =
        "20";


    cameraContainer.appendChild(
        faceLandmarkCanvas
    );


    faceLandmarkContext =
        faceLandmarkCanvas.getContext(
            "2d"
        );


    resizeFaceLandmarkCanvas();


    console.log(
        "Facial landmark canvas created."
    );

}

/* =========================================
   RESIZE LANDMARK CANVAS
   ========================================= */

function resizeFaceLandmarkCanvas() {

    if (
        !faceLandmarkCanvas ||
        !faceLandmarkContext
    ) {
        return;
    }

    const rect =
        cameraContainer.getBoundingClientRect();

    const pixelRatio =
        window.devicePixelRatio || 1;

    faceLandmarkCanvas.width =
        rect.width * pixelRatio;

    faceLandmarkCanvas.height =
        rect.height * pixelRatio;

    faceLandmarkContext.setTransform(
        pixelRatio,
        0,
        0,
        pixelRatio,
        0,
        0
    );

}

/* =========================================
   DRAW FACIAL LANDMARKS
   ========================================= */

function drawFaceLandmarks(landmarks) {

    console.log(
    "LANDMARK DRAW:",
    landmarks.length
);

    if (
        !faceLandmarkCanvas ||
        !faceLandmarkContext ||
        !landmarks
    ) {
        return;
    }

    const videoWidth =
        cameraVideo.videoWidth;

    const videoHeight =
        cameraVideo.videoHeight;

    const containerWidth =
        cameraContainer.clientWidth;

    const containerHeight =
        cameraContainer.clientHeight;

    if (
        !videoWidth ||
        !videoHeight ||
        !containerWidth ||
        !containerHeight
    ) {
        return;
    }

    /*
        The camera uses:

        object-fit: cover

        Therefore the video is scaled until it
        completely covers the camera container.
        Part of the original video can be cropped.

        We must reproduce that exact transformation
        for the landmarks.
    */

    const scale =
        Math.max(
            containerWidth / videoWidth,
            containerHeight / videoHeight
        );

    const displayedWidth =
        videoWidth * scale;

    const displayedHeight =
        videoHeight * scale;

    const cropX =
        (displayedWidth -
            containerWidth) / 2;

    const cropY =
        (displayedHeight -
            containerHeight) / 2;


    const ctx =
        faceLandmarkContext;


    ctx.clearRect(
        0,
        0,
        containerWidth,
        containerHeight
    );

    ctx.beginPath();

ctx.arc(
    window.innerWidth / 2,
    window.innerHeight / 2,
    30,
    0,
    Math.PI * 2
);

ctx.fillStyle =
    "red";

ctx.fill();

    for (
        const landmark of landmarks
    ) {

        /*
            MediaPipe coordinates are normalized:

            X = 0 → left
            X = 1 → right

            Because the camera preview is mirrored,
            reverse the X coordinate.
        */

        const mirroredX =
            1 - landmark.x;


        const x =
            mirroredX *
            displayedWidth -
            cropX;


        const y =
            landmark.y *
            displayedHeight -
            cropY;


        /*
            Ignore points that are completely
            outside the visible camera area.
        */

        if (
            x < -5 ||
            x > containerWidth + 5 ||
            y < -5 ||
            y > containerHeight + 5
        ) {
            continue;
        }


        ctx.beginPath();

        ctx.arc(
            x,
            y,
            1.8,
            0,
            Math.PI * 2
        );

        ctx.fillStyle =
            "rgba(255,255,255,0.9)";

        ctx.fill();

    }


    /*
        Highlight important landmarks.
    */

    drawImportantLandmark(
        landmarks[1],
        displayedWidth,
        displayedHeight,
        cropX,
        cropY,
        5
    );


    drawImportantLandmark(
        landmarks[33],
        displayedWidth,
        displayedHeight,
        cropX,
        cropY,
        4
    );


    drawImportantLandmark(
        landmarks[263],
        displayedWidth,
        displayedHeight,
        cropX,
        cropY,
        4
    );


    drawImportantLandmark(
        landmarks[61],
        displayedWidth,
        displayedHeight,
        cropX,
        cropY,
        4
    );


    drawImportantLandmark(
        landmarks[291],
        displayedWidth,
        displayedHeight,
        cropX,
        cropY,
        4
    );


    drawImportantLandmark(
        landmarks[152],
        displayedWidth,
        displayedHeight,
        cropX,
        cropY,
        4
    );

}


/* =========================================
   IMPORTANT LANDMARK
   ========================================= */

function drawImportantLandmark(
    landmark,
    displayedWidth,
    displayedHeight,
    cropX,
    cropY,
    radius
) {

    if (!landmark) {
        return;
    }


    const mirroredX =
        1 - landmark.x;


    const x =
        mirroredX *
        displayedWidth -
        cropX;


    const y =
        landmark.y *
        displayedHeight -
        cropY;


    if (
        x < -10 ||
        x > cameraContainer.clientWidth + 10 ||
        y < -10 ||
        y > cameraContainer.clientHeight + 10
    ) {
        return;
    }


    faceLandmarkContext.beginPath();

    faceLandmarkContext.arc(
        x,
        y,
        radius,
        0,
        Math.PI * 2
    );

    faceLandmarkContext.fillStyle =
        "rgba(255,80,80,0.95)";

    faceLandmarkContext.fill();

}


/* =========================================
   DRAW IMPORTANT LANDMARK
   ========================================= */

function drawImportantLandmark(
    landmark,
    videoRect,
    radius
) {

    if (!landmark) {
        return;
    }


    const x =
        videoRect.left +
        (
            landmark.x *
            videoRect.width
        );


    const y =
        videoRect.top +
        (
            landmark.y *
            videoRect.height
        );


    faceLandmarkContext.beginPath();


    faceLandmarkContext.arc(
        x,
        y,
        radius,
        0,
        Math.PI * 2
    );


    faceLandmarkContext.fillStyle =
        "rgba(255, 80, 80, 0.95)";


    faceLandmarkContext.fill();

}

/* =========================================
   FACE TRACKING
   ========================================= */

async function initializeFaceLandmarker() {

    if (faceTrackingReady) {

        return true;

    }


    setFaceTrackingStatus(
        "LOADING FACE TRACKER...",
        "loading"
    );


    try {

        console.log(
            "Loading MediaPipe Face Landmarker..."
        );


        const vision =
            await import(
                "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision/vision_bundle.mjs"
            );


        const {
            FaceLandmarker,
            FilesetResolver
        } = vision;


        console.log(
            "MediaPipe library loaded."
        );


        const fileset =
            await FilesetResolver.forVisionTasks(
                MEDIAPIPE_WASM_PATH
            );


        console.log(
            "MediaPipe WASM loaded."
        );


        faceLandmarker =
            await FaceLandmarker.createFromOptions(
                fileset,
                {

                    baseOptions: {

                        modelAssetPath:
                            FACE_LANDMARKER_MODEL_PATH

                    },

                    runningMode:
                        "VIDEO",

                    numFaces:
                        1,

                    minFaceDetectionConfidence:
                        0.5,

                    minFacePresenceConfidence:
                        0.5,

                    minTrackingConfidence:
                        0.5,

                    outputFaceBlendshapes:
                        true,

                    outputFacialTransformationMatrixes:
                        true

                }
            );


        faceTrackingReady =
            true;


        setFaceTrackingStatus(
            "FACE TRACKER READY",
            "ready"
        );


        console.log(
            "MediaPipe Face Landmarker ready."
        );


        return true;


    } catch (error) {

        console.error(
            "Face Landmarker initialization error:",
            error
        );


        setFaceTrackingStatus(
            "FACE TRACKER ERROR",
            "error"
        );


        return false;

    }

}


/* =========================================
   START FACE TRACKING
   ========================================= */

async function startFaceTracking() {

    console.log(
        "Starting face tracking..."
    );

    createFaceLandmarkCanvas();

    if (
        faceTrackingRunning
    ) {

        console.log(
            "Face tracking is already running."
        );

        return;

    }


    if (
        cameraVideo.readyState <
        HTMLMediaElement.HAVE_CURRENT_DATA
    ) {

        console.log(
            "Waiting for camera video..."
        );


        await waitForVideoReady();

    }


    const ready =
        await initializeFaceLandmarker();


    if (!ready) {

        return;

    }


    faceTrackingRunning =
        true;


    setFaceTrackingStatus(
        "NO FACE DETECTED",
        "no-face"
    );


    faceTrackingFrameID =
        requestAnimationFrame(
            processFaceFrame
        );


    console.log(
        "Face tracking started."
    );

}


/* =========================================
   WAIT FOR VIDEO
   ========================================= */

function waitForVideoReady() {

    return new Promise(
        (resolve) => {

            if (
                cameraVideo.readyState >=
                HTMLMediaElement.HAVE_CURRENT_DATA
            ) {

                resolve();

                return;

            }


            cameraVideo.addEventListener(
                "loadeddata",
                () => {

                    resolve();

                },
                {
                    once: true
                }
            );

        }
    );

}


/* =========================================
   PROCESS CAMERA FRAME
   ========================================= */

function processFaceFrame(
    timestamp
) {

    if (
        !faceTrackingRunning ||
        !faceLandmarker
    ) {

        return;

    }


    if (
        cameraVideo.readyState <
        HTMLMediaElement.HAVE_CURRENT_DATA
    ) {

        faceTrackingFrameID =
            requestAnimationFrame(
                processFaceFrame
            );

        return;

    }


    try {

        const result =
            faceLandmarker.detectForVideo(
                cameraVideo,
                timestamp
            );


        const faceFound =
            result &&
            result.faceLandmarks &&
            result.faceLandmarks.length > 0;


        if (faceFound) {

            setFaceTrackingStatus(
                "FACE DETECTED",
                "face-found"
            );


            lastFaceDetectionTime =
                timestamp;


            const landmarks =
                result.faceLandmarks[0];

            drawFaceLandmarks(
                landmarks
            );


            /*
                STEP 3:
                Face position.
            */

            const position =
                calculateFacePosition(
                    landmarks
                );


            updateFacePositionDebug(
                position
            );


            /*
                STEP 4:
                Head movement.
            */

            const movement =
                calculateHeadMovement(
                    landmarks
                );


            updateHeadMovementDebug(
                movement
            );

            if (
            faceLandmarkContext
    ) {

    faceLandmarkContext.clearRect(
        0,
        0,
        window.innerWidth,
        window.innerHeight
    );

}

            /*
                Smile detection.
            */

            processSmileDetection(
                result,
                timestamp
            );

        } else {

            setFaceTrackingStatus(
                "NO FACE DETECTED",
                "no-face"
            );


            updateFacePositionDebug(
                null
            );


            updateHeadMovementDebug(
                null
            );


            processSmileDetection(
                null,
                timestamp
            );

        }


    } catch (error) {

        console.error(
            "Face tracking frame error:",
            error
        );


        setFaceTrackingStatus(
            "FACE TRACKER ERROR",
            "error"
        );

    }


    faceTrackingFrameID =
        requestAnimationFrame(
            processFaceFrame
        );

}


/* =========================================
   FACE TRACKING STATUS
   ========================================= */

function setFaceTrackingStatus(
    message,
    state
) {

    if (
        !faceTrackingStatus ||
        !faceStatusText
    ) {

        return;

    }


    faceTrackingStatus.classList.remove(
        "face-found",
        "no-face",
        "error"
    );


    faceStatusText.textContent =
        message;


    if (
        state ===
        "face-found"
    ) {

        faceTrackingStatus.classList.add(
            "face-found"
        );

    }


    if (
        state ===
        "no-face"
    ) {

        faceTrackingStatus.classList.add(
            "no-face"
        );

    }


    if (
        state ===
        "error"
    ) {

        faceTrackingStatus.classList.add(
            "error"
        );

    }


    faceTrackingStatus.classList.remove(
        "hidden"
    );

}


/* =========================================
   STOP FACE TRACKING
   ========================================= */

function stopFaceTracking() {

    faceTrackingRunning =
        false;


    smileDetectionEnabled =
        false;


    if (
        faceTrackingFrameID !==
        null
    ) {

        cancelAnimationFrame(
            faceTrackingFrameID
        );

        faceTrackingFrameID =
            null;

    }


    if (
        facePositionDebugElement
    ) {

        facePositionDebugElement.remove();

        facePositionDebugElement =
            null;

    }


    if (
        headMovementDebugElement
    ) {

        headMovementDebugElement.remove();

        headMovementDebugElement =
            null;

    }

    if (
    faceLandmarkCanvas
) {

    faceLandmarkCanvas.remove();

    faceLandmarkCanvas =
        null;

    faceLandmarkContext =
        null;

}


window.removeEventListener(
    "resize",
    resizeFaceLandmarkCanvas
);

}


/* =========================================
   CAMERA PERMISSION DENIED
   ========================================= */

function showCameraPermissionDenied() {

    stopFaceTracking();


    cameraContainer.classList.add(
        "hidden"
    );


    cameraInteractionContainer.classList.add(
        "hidden"
    );


    faceTrackingStatus.classList.add(
        "hidden"
    );


    dialogueText.classList.remove(
        "hidden"
    );


    playDialogue(
        DIALOGUE.cameraCall.permissionDenied,
        finishVersion
    );

}


/* =========================================
   DECLINE VIDEO CALL
   ========================================= */

declineCallButton.addEventListener(
    "click",
    handleDeclineCall
);


function handleDeclineCall() {

    stopFaceTracking();


    videoCallContainer.classList.add(
        "hidden"
    );


    cameraInteractionContainer.classList.add(
        "hidden"
    );


    faceTrackingStatus.classList.add(
        "hidden"
    );


    dialogueText.classList.remove(
        "hidden"
    );


    playDialogue(
        DIALOGUE.cameraCall.declined,
        finishVersion
    );

}


/* =========================================
   CAMERA STAGE COMPLETE
   ========================================= */

function finishCameraStage() {

    smileDetectionEnabled =
        false;


    console.log(
        "v0.4.0 friendly camera interaction completed."
    );

}


/* =========================================
   END OF PROTOTYPE
   ========================================= */

function finishVersion() {

    typeDialogue(
        "We'll meet here soon.",
        () => {

            console.log(
                "Current prototype complete."
            );

        }
    );

}