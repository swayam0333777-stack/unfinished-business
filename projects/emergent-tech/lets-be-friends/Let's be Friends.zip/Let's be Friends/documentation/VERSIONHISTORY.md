# Evil Replica — Version History

This document records the development history of the **Evil Replica** interactive web experience.

The project is being developed progressively so that every major milestone remains independently understandable and testable.

---

# v0.1.0 — First Conversation

**Date:** 21 August 2026

**Status:** Working Prototype

### Description

The first working version of the experience.

The project begins with a minimal white interface and introduces the player to the digital character through a simple conversation.

### Major Features

- White background.
- Minimal typography.
- Opening dialogue.
- Typing effect.
- Player name input.
- Character responses using the player's name.
- Friendship conversation.
- YES / NO interaction.
- Character attempts to convince the player when appropriate.
- Camera invitation at the end of the conversation.
- Space bar dialogue skipping.
- Ctrl + S development shortcut.

### Documentation

[View v0.1.0 Documentation](versions/v0.1.0.md)

---

# v0.2.0 — Camera & Incoming FaceTime Call

**Date:** 21 August 2026

**Status:** Working Prototype

### Description

The second milestone introduces the webcam interaction.

The camera is not requested immediately. Instead, the character first develops a relationship with the player and only later asks to see them.

The player receives an incoming FaceTime-style call and can choose whether to accept it.

### Major Features

- Browser camera permission.
- Incoming FaceTime-style call popup.
- Centered stretched pill-shaped call interface.
- Caller displayed as `Unknown`.
- `Incoming FaceTime` label.
- Accept and Decline controls.
- Camera activation after accepting.
- Full-screen mirrored webcam.
- White dialogue over the camera feed.
- Dialogue cancellation when entering the camera stage.
- Ctrl + S development shortcut to jump to the call.
- Space bar dialogue skipping.

### Important Fixes

- Prevented previous dialogue from restarting after the camera opened.
- Cancelled delayed dialogue callbacks when skipping the conversation.
- Corrected call action icons.
- Improved incoming-call popup proportions.
- Changed the call popup to a smaller centered pill.
- Removed unnecessary interface elements from the call popup.

### Current Limitations

The camera displays the user's webcam but does not yet understand or track the user's face.

There is currently:

- No face tracking.
- No facial landmark detection.
- No replica.
- No movement following.
- No delay.
- No glitches.
- No horror effects.

### Documentation

[View v0.2.0 Documentation](versions/v0.2.0.md)

---

# v0.3.0 — Friendly Camera Interaction

**Date:** 21 August 2026

**Status:** Working Prototype

### Description

v0.3.0 introduces the first friendly interaction after the camera call is accepted.

The purpose of this version is to make the player feel comfortable with the character before any unsettling behaviour is introduced.

The character acknowledges seeing the player and asks them to perform simple actions.

### Major Features

- Friendly camera introduction.
- Personalized greeting.
- Friendly camera-stage dialogue.
- Wave interaction.
- Smile interaction.
- Character reactions.
- Camera interaction buttons.
- Smooth transition between dialogue and interaction.
- Continued typing effect during the camera stage.

### Current Interaction Flow

**Camera accepted**

↓

**Oh...**

↓

**There you are.**

↓

**Hi, [name]!**

↓

**It's nice to finally see you.**

↓

**Can you wave?**

↓

**👋 I waved**

↓

**Haha!**

↓

**You actually did it!**

↓

**Can you smile for me?**

↓

**😊 I smiled**

↓

**That's a nice smile.**

↓

**I like seeing you like this.**

### Important Limitation

The wave and smile interactions are currently simulated.

The application does not yet determine whether the user actually performed the requested action.

This is temporary.

Actual face tracking is introduced in v0.4.0.

### Design Purpose

v0.3.0 establishes:

**Connection**

↓

**Comfort**

↓

**Familiarity**

The player should feel that the character is genuinely interested in them.

The experience should still feel pleasant.

### Horror Status

No horror has been introduced.

There are currently no:

- Glitches.
- Movement delays.
- Black eyes.
- Creepy smile.
- Independent replica behaviour.
- Facial distortion.
- Horror sounds.

### Documentation

[View v0.3.0 Documentation](versions/v0.3.0.md)

---

# v0.4.0 — Face Tracking

**Date:** 21 August 2026

**Status:** In Development

### Description

v0.4.0 begins the transition from a simple webcam interaction to an experience that can actually understand the player's face.

The first step is basic real-time face detection.

### Step 1 — Basic Face Detection

MediaPipe Face Landmarker has been successfully integrated into the project.

The local Face Landmarker model is stored at:

`assets/models/face_landmarker.task`

The browser successfully loads the model and processes the live camera feed.

### Major Features Added

- MediaPipe Face Landmarker.
- Local model file.
- Real-time video processing.
- Face presence detection.
- Face tracking status indicator.
- `FACE DETECTED` state.
- `NO FACE DETECTED` state.
- Face tracker loading state.
- Face tracker error state.
- Debug logging.

### Current Behaviour

When the player is visible:

**FACE DETECTED**

When the player moves completely outside the camera view:

**NO FACE DETECTED**

The system successfully changes between these states in real time.

### Current Technical Foundation

The Face Landmarker is configured to provide:

- Face landmarks.
- Facial blendshapes.
- Facial transformation information.

The returned landmark data is not yet being used to control the visual replica.

### Current Limitations

The system does not yet:

- Detect smiles.
- Detect waving.
- Track head movement for visual interaction.
- Create a replica.
- Delay replica movement.
- Manipulate facial features.
- Introduce glitches.
- Introduce horror.

### Design Status

The character remains completely friendly.

The face-tracking status indicator is currently a development/debug feature and is not intended to remain in the final experience.

### Next Step

**v0.4.0 — Facial Landmark & Expression Detection**

The next development step will use the Face Landmarker data to detect basic facial expressions, beginning with the player's smile.

---

# v0.5.0 — First Glitch

**Status:** Planned

### Goal

Introduce the first subtle indication that the replica does not behave perfectly.

### Planned Features

- Small movement delay.
- Slight response lag.
- First timing error.
- Brief visual anomaly.

### Documentation

Will be added when v0.5.0 is completed.

---

# v0.6.0 — Independent Replica

**Status:** Planned

### Goal

The replica begins behaving independently from the player.

### Planned Features

- Incorrect movements.
- Delayed reactions.
- Independent actions.
- Replica watching the user.
- Increasingly unnatural behaviour.

### Documentation

Will be added when v0.6.0 is completed.

---

# v0.7.0 — Horror Effects

**Status:** Planned

### Goal

Begin the transformation from uncanny to disturbing.

### Planned Features

- Visual flickers.
- Black eyes.
- Unnatural smile.
- Facial distortion.
- Disturbing dialogue.
- Increasingly possessive behaviour.

### Documentation

Will be added when v0.7.0 is completed.

---

# v1.0.0 — Final Experience

**Status:** Planned

### Goal

Complete the final 2–3 minute interactive experience.

### Planned Features

- Complete emotional progression.
- Polished dialogue.
- Full face tracking.
- Independent replica.
- Horror progression.
- Sound design.
- Final transformation.
- Final dialogue.
- Final visual polish.
- Complete documentation.

### Documentation

Will be added when v1.0.0 is completed.