# Evil Replica — Changelog

This file records the major changes made throughout the development of the **Evil Replica** interactive experience.

---

## v0.1.0 — First Conversation

**Date:** 21 August 2026  
**Status:** Working Prototype

### Added

- White background.
- Minimal typography.
- Opening dialogue.
- Typing dialogue effect.
- Player name input.
- Character responses using the player's name.
- Friendship conversation.
- YES / NO interaction.
- Character attempts to convince the player when appropriate.
- Camera invitation at the end of the conversation.
- Space bar dialogue skipping.
- Ctrl + S development shortcut.

### Known Issues

- No camera.
- No face tracking.
- No replica.
- No horror effects.

### Next Goal

Camera integration.

---

## v0.2.0 — Camera & Incoming FaceTime Call

**Date:** 21 August 2026  
**Status:** Working Prototype

### Added

- Browser camera permission.
- Incoming FaceTime-style call popup.
- Centered stretched pill-shaped call interface.
- Generic caller name displayed as `Unknown`.
- `Incoming FaceTime` label.
- Accept call button.
- Decline call button.
- Camera activation after accepting the call.
- Full-screen mirrored webcam.
- White dialogue over the camera feed.

### Interaction Improvements

- Camera is not requested when the webpage first loads.
- Camera is introduced only after the character has built trust.
- User can choose whether to proceed to the camera interaction.
- Refusal can lead to additional convincing dialogue.
- Incoming call feels like a natural continuation of the conversation.

### Development Features

- Space bar skips the currently typing dialogue line.
- Ctrl + S can skip directly to the incoming call during development.
- Previous dialogue sessions are cancelled when the conversation is skipped.

### Bugs Fixed

- Fixed dialogue restarting after camera activation.
- Fixed old dialogue timers continuing after the conversation was skipped.
- Fixed camera dialogue appearing black over the webcam.
- Fixed incorrect call button symbols.
- Improved incoming-call popup alignment and proportions.
- Reduced the call popup to a smaller centered pill.

### Known Issues

- No face tracking.
- No facial landmark detection.
- No replica behaviour.
- No movement following.
- No intentional movement delay.
- No glitches.
- No horror effects.

### Next Goal

Friendly camera interaction.

---

## v0.3.0 — Friendly Camera Interaction

**Date:** 21 August 2026  
**Status:** Working Prototype

### Added

- Friendly camera introduction.
- Camera-stage dialogue.
- Personalized camera greeting.
- Friendly interaction prompts.
- Wave interaction.
- Smile interaction.
- Character reactions to the player's simulated actions.
- Camera interaction buttons.
- Smooth transition between dialogue and interaction buttons.
- Friendly emotional progression after the camera is accepted.

### Camera Dialogue

The camera interaction includes:

- `Oh...`
- `There you are.`
- `Hi, [name]!`
- `It's nice to finally see you.`
- `Can you wave?`
- `Haha!`
- `You actually did it!`
- `Can you smile for me?`
- `That's a nice smile.`
- `I like seeing you like this.`

### Interaction

The player can currently respond using:

- `👋 I waved`
- `😊 I smiled`

These interactions are currently **simulated buttons**.

The application does not yet detect whether the user actually waved or smiled.

### Important Design Decision

The horror has deliberately NOT been introduced at this stage.

There are currently:

- No glitches.
- No delays.
- No black eyes.
- No creepy smile.
- No independent movement.
- No distorted face.
- No horror sounds.

### Known Issues

- Wave detection is not real.
- Smile detection is not real.
- No face tracking.
- No facial landmarks.
- No replica movement.

### Next Goal

Face tracking.

---

## v0.4.0 — Face Tracking

**Date:** 21 August 2026  
**Status:** In Development

### Step 1 — Basic Face Detection

The first face-tracking milestone has been successfully completed.

### Added

- MediaPipe Face Landmarker integration.
- Local `face_landmarker.task` model.
- Browser-based face detection.
- Real-time camera analysis.
- Face presence detection.
- Face tracking status indicator.
- `FACE DETECTED` state.
- `NO FACE DETECTED` state.
- Face tracker loading state.
- Face tracker error state.
- Console debugging information for the face-tracking system.

### Local Model

The Face Landmarker model is stored locally inside:

`assets/models/face_landmarker.task`

The browser loads the model from the project rather than requiring the model itself to be stored on a remote server.

### Current Detection

The system can now determine whether a face is visible in the camera.

When the player's face is visible:

`FACE DETECTED`

When the player's face leaves the camera:

`NO FACE DETECTED`

### Technical Foundation

The Face Landmarker is currently configured for:

- Video mode.
- One detected face.
- Face landmarks.
- Facial blendshape output.
- Facial transformation matrix output.

The landmark information is currently being detected but is not yet being used to control the visual replica.

### Important Limitation

The system currently detects the presence of a face.

It does NOT yet:

- Detect a smile.
- Detect a wave.
- Control a replica.
- Track movement visually.
- Manipulate the user's eyes.
- Manipulate the user's mouth.
- Introduce delays.
- Introduce glitches.
- Introduce horror.

### Design Status

The emotional experience remains completely friendly.

The face-tracking system is currently invisible apart from the temporary development status indicator.

### Next Step

**v0.4.0 — Step 2: Facial Landmark & Expression Detection**

The next stage will begin using the information returned by the Face Landmarker.

The first target will be smile detection.

The existing simulated:

`😊 I smiled`

interaction will eventually be replaced by actual detection of the player's smile.

---

## v0.5.0 — First Glitch

**Status:** Planned

### Planned

- Small movement delay.
- Slight response lag.
- First subtle timing error.
- Brief visual anomaly.

---

## v0.6.0 — Independent Replica

**Status:** Planned

### Planned

- Incorrect movements.
- Delayed reactions.
- Independent actions.
- Replica watching the user.
- Increasingly unnatural behaviour.

---

## v0.7.0 — Horror Effects

**Status:** Planned

### Planned

- Visual flickers.
- Black eyes.
- Unnatural smile.
- Facial distortion.
- Disturbing dialogue.
- Increasingly possessive behaviour.

---

## v1.0.0 — Final Experience

**Status:** Planned

### Planned

- Complete emotional progression.
- Full face tracking.
- Independent replica.
- Horror progression.
- Sound design.
- Final transformation.
- Final dialogue.
- Final visual polish.
- Complete documentation.