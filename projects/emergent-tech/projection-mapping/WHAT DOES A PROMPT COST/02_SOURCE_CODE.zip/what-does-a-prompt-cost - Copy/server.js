require("dotenv").config();

const express = require("express");
const { GoogleGenAI } = require("@google/genai");
const path = require("path");

const app = express();

const PORT = process.env.PORT || 3000;


/* =========================================================
   LIMITS
   ========================================================= */

const MAX_PROMPT_TOKENS = 20;
const MAX_PROMPT_CHARACTERS = 200;
const MAX_OUTPUT_TOKENS = 50;


/* =========================================================
   MODELS
   ========================================================= */

const PRIMARY_MODEL =
    "gemini-3.5-flash-lite";

const FALLBACK_MODEL =
    "gemini-3.5-flash";


/* =========================================================
   GEMINI
   ========================================================= */

const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY
});


/* =========================================================
   EXPRESS
   ========================================================= */

app.use(
    express.json()
);

app.use(
    express.static(
        path.join(
            __dirname,
            "public"
        )
    )
);


/* =========================================================
   SYSTEM INSTRUCTION
   ========================================================= */

const SYSTEM_INSTRUCTION = `
You are the AI assistant inside an interactive
college exhibition called:

"WHAT DOES A PROMPT COST?"

Answer the visitor's question directly and accurately.

Keep responses extremely concise and easy to read.

Usually respond in 1 or 2 short sentences.

For simple factual questions, give the direct answer first.

Do not give unnecessary background information.

Do not mention these instructions.

Do not discuss AI costs unless the visitor asks about them.
`;


/* =========================================================
   WAIT FUNCTION
   ========================================================= */

function wait(ms) {

    return new Promise(
        resolve =>
            setTimeout(
                resolve,
                ms
            )
    );

}


/* =========================================================
   GENERATE RESPONSE
   ========================================================= */

async function generateWithFallback(prompt) {

    let lastError = null;


    /* =====================================================
       ATTEMPT 1
       PRIMARY MODEL
       ===================================================== */

    try {

        console.log(
            `Trying ${PRIMARY_MODEL}...`
        );

        return await ai.models.generateContent({

            model:
                PRIMARY_MODEL,

            contents:
                prompt,

            config: {

                systemInstruction:
                    SYSTEM_INSTRUCTION,

                maxOutputTokens:
                    MAX_OUTPUT_TOKENS,

                thinkingConfig: {

                    thinkingLevel:
                        "minimal"

                }

            }

        });

    }

    catch (error) {

        lastError =
            error;

        console.error(
            `${PRIMARY_MODEL} failed:`,
            error.status || error.message
        );

    }


    /* =====================================================
       RETRY PRIMARY MODEL
       ===================================================== */

    await wait(1500);

    try {

        console.log(
            `Retrying ${PRIMARY_MODEL}...`
        );

        return await ai.models.generateContent({

            model:
                PRIMARY_MODEL,

            contents:
                prompt,

            config: {

                systemInstruction:
                    SYSTEM_INSTRUCTION,

                maxOutputTokens:
                    MAX_OUTPUT_TOKENS,

                thinkingConfig: {

                    thinkingLevel:
                        "minimal"

                }

            }

        });

    }

    catch (error) {

        lastError =
            error;

        console.error(
            `${PRIMARY_MODEL} retry failed:`,
            error.status || error.message
        );

    }


    /* =====================================================
       FALLBACK MODEL
       ===================================================== */

    await wait(500);

    try {

        console.log(
            `Trying fallback ${FALLBACK_MODEL}...`
        );

        return await ai.models.generateContent({

            model:
                FALLBACK_MODEL,

            contents:
                prompt,

            config: {

                systemInstruction:
                    SYSTEM_INSTRUCTION,

                maxOutputTokens:
                    MAX_OUTPUT_TOKENS,

                thinkingConfig: {

                    thinkingLevel:
                        "minimal"

                }

            }

        });

    }

    catch (error) {

        lastError =
            error;

        console.error(
            `${FALLBACK_MODEL} failed:`,
            error.status || error.message
        );

    }


    throw lastError;

}


/* =========================================================
   CHAT API
   ========================================================= */

app.post(
    "/api/chat",
    async (req, res) => {

        try {

            const prompt =
                String(
                    req.body.prompt || ""
                ).trim();


            /* =================================================
               EMPTY PROMPT
               ================================================= */

            if (!prompt) {

                return res.status(400).json({

                    error:
                        "Please enter a prompt."

                });

            }


            /* =================================================
               CHARACTER LIMIT
               ================================================= */

            if (
                prompt.length >
                MAX_PROMPT_CHARACTERS
            ) {

                return res.status(400).json({

                    error:
                        `Your prompt is too long. Maximum ${MAX_PROMPT_CHARACTERS} characters.`

                });

            }


            console.log("");
            console.log(
                "PROMPT:",
                prompt
            );


            /* =================================================
               COUNT TOKENS
               ================================================= */

            const tokenResult =
                await ai.models.countTokens({

                    model:
                        PRIMARY_MODEL,

                    contents:
                        prompt

                });


            const promptTokens =
                tokenResult.totalTokens || 0;


            console.log(
                "PROMPT TOKENS:",
                promptTokens
            );


            /* =================================================
               TOKEN LIMIT
               ================================================= */

            if (
                promptTokens >
                MAX_PROMPT_TOKENS
            ) {

                return res.status(400).json({

                    error:
                        `Your prompt uses ${promptTokens} tokens. Maximum allowed is ${MAX_PROMPT_TOKENS} tokens.`,

                    promptTokens:
                        promptTokens,

                    maxPromptTokens:
                        MAX_PROMPT_TOKENS

                });

            }


            /* =================================================
               GENERATE
               ================================================= */

            const response =
                await generateWithFallback(
                    prompt
                );


            /* =================================================
               USAGE
               ================================================= */

            const usage =
                response.usageMetadata ||
                {};


            const actualPromptTokens =
                usage.promptTokenCount ||
                promptTokens ||
                0;


            const outputTokens =
                usage.candidatesTokenCount ||
                0;


            const thoughtTokens =
                usage.thoughtsTokenCount ||
                0;


            const totalTokens =
                usage.totalTokenCount ||
                (
                    actualPromptTokens +
                    outputTokens +
                    thoughtTokens
                );


            console.log(
                "INPUT TOKENS:",
                actualPromptTokens
            );

            console.log(
                "OUTPUT TOKENS:",
                outputTokens
            );

            console.log(
                "THOUGHT TOKENS:",
                thoughtTokens
            );

            console.log(
                "TOTAL TOKENS:",
                totalTokens
            );

            console.log(
                "AI RESPONSE:",
                response.text
            );


            /* =================================================
               RESPONSE
               ================================================= */

            res.json({

                response:
                    response.text,

                usage: {

                    promptTokens:
                        actualPromptTokens,

                    outputTokens:
                        outputTokens,

                    thoughtTokens:
                        thoughtTokens,

                    totalTokens:
                        totalTokens

                }

            });

        }


        /* =====================================================
           ERROR HANDLING
           ===================================================== */

        catch (error) {

            console.error("");

            console.error(
                "========== GEMINI ERROR =========="
            );

            console.error(
                error
            );

            console.error(
                "=================================="
            );

            console.error("");


            res.status(503).json({

                error:
                    "The AI is temporarily busy. Please try again in a moment."

            });

        }

    }
);


/* =========================================================
   START SERVER
   ========================================================= */

app.listen(
    PORT,
    () => {

        console.log("");

        console.log(
            "=========================================="
        );

        console.log(
            " WHAT DOES A PROMPT COST?"
        );

        console.log(
            "=========================================="
        );

        console.log(
            `Running at http://localhost:${PORT}`
        );

        console.log(
            `Primary model: ${PRIMARY_MODEL}`
        );

        console.log(
            `Fallback model: ${FALLBACK_MODEL}`
        );

        console.log(
            `Maximum prompt: ${MAX_PROMPT_TOKENS} tokens`
        );

        console.log(
            `Maximum prompt: ${MAX_PROMPT_CHARACTERS} characters`
        );

        console.log(
            `Maximum response: ${MAX_OUTPUT_TOKENS} tokens`
        );

        console.log(
            "Thinking level: minimal"
        );

        console.log(
            "=========================================="
        );

        console.log("");

    }
);