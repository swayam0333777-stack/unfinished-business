/* =========================================================
   WHAT DOES A PROMPT COST?
   INTERACTIVE AI + ENVIRONMENTAL COST
   ========================================================= */


/* =========================================================
   SESSION TOTALS
   ========================================================= */

let promptCount = 0;

let totalEnergy = 0;
let totalHeat = 0;
let totalWater = 0;


/* =========================================================
   SESSION LIMIT
   ========================================================= */

const MAX_SESSION_PROMPTS = 20;


/* =========================================================
   REQUEST COOLDOWN
   ========================================================= */

const REQUEST_COOLDOWN = 5000;

let lastRequestTime = 0;


/* =========================================================
   ENVIRONMENTAL ESTIMATE

   Published median reference:

   Energy = 0.24 Wh
   Water  = 0.26 mL

   Heat:

   1 Wh = 3.6 kJ

   IMPORTANT:
   These values are estimates, not direct measurements
   of an individual prompt.

   We use actual Gemini token usage as a
   complexity indicator rather than claiming
   a universal Wh-per-token conversion.
   ========================================================= */

const ENERGY_PER_PROMPT = 0.24;

const WATER_PER_PROMPT = 0.26;

const HEAT_PER_WH = 3.6;


/* =========================================================
   TOKEN-WEIGHTING SETTINGS
   ========================================================= */

/*
   The published reference is treated as the baseline
   for a typical text prompt.

   Gemini returns actual token usage after generation.

   We compare the request's total token workload against
   a reference workload.

   This is an ESTIMATE, not a measured energy value.
*/

const REFERENCE_TOTAL_TOKENS = 114;


/*
   Prevent extremely small or extremely large values.

   This keeps the exhibition visually sensible.
*/

const MIN_COST_MULTIPLIER = 0.70;

const MAX_COST_MULTIPLIER = 2.50;


/* =========================================================
   PROMPT LIMIT
   ========================================================= */

const MAX_PROMPT_LENGTH = 200;

const MAX_PROMPT_TOKENS = 20;


/* =========================================================
   ELEMENTS
   ========================================================= */

const form =
    document.getElementById("promptForm");


const input =
    document.getElementById("promptInput");


const characterCount =
    document.getElementById("characterCount");


const sendButton =
    document.getElementById("sendButton");


const conversation =
    document.getElementById("conversation");


const promptCounter =
    document.getElementById("promptCount");


const energyValue =
    document.getElementById("energyValue");


const heatValue =
    document.getElementById("heatValue");


const waterValue =
    document.getElementById("waterValue");


const methodButton =
    document.getElementById("methodButton");


const methodology =
    document.getElementById("methodology");


const closeMethod =
    document.getElementById("closeMethod");


const aboutButton =
    document.getElementById("aboutButton");


const aboutPoster =
    document.getElementById("aboutPoster");


const closeAbout =
    document.getElementById("closeAbout");


/* =========================================================
   CHARACTER COUNTER
   ========================================================= */

input.addEventListener(

    "input",

    function () {

        const length =
            input.value.length;


        characterCount.textContent =
            `${length} / ${MAX_PROMPT_LENGTH}`;


        if (
            length >= MAX_PROMPT_LENGTH
        ) {

            characterCount.classList.add(
                "limit-reached"
            );

        }

        else {

            characterCount.classList.remove(
                "limit-reached"
            );

        }

    }

);


/* =========================================================
   SESSION LIMIT CHECK
   ========================================================= */

function sessionLimitReached() {

    return (
        promptCount >=
        MAX_SESSION_PROMPTS
    );

}


/* =========================================================
   SEND PROMPT
   ========================================================= */

form.addEventListener(

    "submit",

    async function (event) {

        event.preventDefault();


        /* -----------------------------------------
           SESSION LIMIT
           ----------------------------------------- */

        if (
            sessionLimitReached()
        ) {

            addAIMessage(

                "SESSION COMPLETE — You have reached the 20-prompt limit for this session."

            );

            input.disabled = true;

            sendButton.disabled = true;

            return;

        }


        const prompt =
            input.value.trim();


        if (!prompt) {

            return;

        }


        /* -----------------------------------------
           CHARACTER LIMIT
           ----------------------------------------- */

        if (
            prompt.length >
            MAX_PROMPT_LENGTH
        ) {

            addAIMessage(

                `Your prompt is too long. Maximum ${MAX_PROMPT_LENGTH} characters.`

            );

            return;

        }


        /* -----------------------------------------
           REQUEST COOLDOWN
           ----------------------------------------- */

        const now =
            Date.now();


        const timeSinceLastRequest =
            now -
            lastRequestTime;


        if (
            timeSinceLastRequest <
            REQUEST_COOLDOWN
        ) {

            const remaining =
                Math.ceil(

                    (
                        REQUEST_COOLDOWN -
                        timeSinceLastRequest

                    ) / 1000

                );


            addAIMessage(

                `Please wait ${remaining} more second${remaining === 1 ? "" : "s"} before asking another question.`

            );

            return;

        }


        lastRequestTime =
            now;


        /* -----------------------------------------
           ADD USER MESSAGE
           ----------------------------------------- */

        addUserMessage(prompt);


        input.value = "";

        characterCount.textContent =
            `0 / ${MAX_PROMPT_LENGTH}`;


        characterCount.classList.remove(
            "limit-reached"
        );


        sendButton.disabled = true;

        input.disabled = true;


        showTyping();


        try {

            const result =
                await fetch(

                    "/api/chat",

                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body:

                            JSON.stringify({

                                prompt:
                                    prompt

                            })

                    }

                );


            const data =
                await result.json();


            removeTyping();


            /* -----------------------------------------
               SERVER ERROR
               ----------------------------------------- */

            if (!result.ok) {

                throw new Error(

                    data.error ||
                    "AI request failed."

                );

            }


            /* -----------------------------------------
               AI RESPONSE + ACTUAL TOKEN USAGE
               ----------------------------------------- */

            const cost =
                calculateEnvironmentalCost(

                    data.usage

                );


            addAIMessage(

                data.response,

                cost

            );


            /* -----------------------------------------
               UPDATE TOTAL
               ----------------------------------------- */

            updateCost(cost);

        }


        catch (error) {

            console.error(
                "CHAT ERROR:",
                error
            );


            removeTyping();


            addAIMessage(

                error.message ||
                "Sorry — I couldn't process that prompt. Please try again."

            );

        }


        finally {

            if (
                !sessionLimitReached()
            ) {

                sendButton.disabled = false;

                input.disabled = false;

            }

            else {

                sendButton.disabled = true;

                input.disabled = true;

            }


            input.focus();

        }

    }

);


/* =========================================================
   USER MESSAGE
   ========================================================= */

function addUserMessage(text) {

    const wrapper =
        document.createElement("div");


    wrapper.className =
        "user-message";


    wrapper.innerHTML = `

        <span class="message-label">
            YOU
        </span>

        <p></p>

    `;


    wrapper
        .querySelector("p")
        .textContent = text;


    conversation.appendChild(
        wrapper
    );


    scrollConversation();

}


/* =========================================================
   AI MESSAGE + COST CARD
   ========================================================= */

function addAIMessage(

    text,

    cost = null

) {

    const wrapper =
        document.createElement("div");


    wrapper.className =
        "ai-message";


    wrapper.innerHTML = `

        <span class="message-label">
            AI
        </span>

        <p class="ai-response-text"></p>

        ${
            cost
            ?
            `

            <div class="prompt-cost-card">

                <div class="prompt-cost-title">
                    THIS PROMPT COST
                </div>


                <div class="prompt-cost-grid">


                    <div class="prompt-cost-item">

                        <span class="prompt-cost-icon">
                            ⚡
                        </span>


                        <div>

                            <div class="prompt-cost-label">
                                ENERGY
                            </div>


                            <div class="prompt-cost-number">

                                ${cost.energy.toFixed(2)}
                                Wh

                            </div>

                        </div>

                    </div>


                    <div class="prompt-cost-item">

                        <span class="prompt-cost-icon">
                            🔥
                        </span>


                        <div>

                            <div class="prompt-cost-label">
                                HEAT
                            </div>


                            <div class="prompt-cost-number">

                                ${cost.heat.toFixed(2)}
                                kJ

                            </div>

                        </div>

                    </div>


                    <div class="prompt-cost-item">

                        <span class="prompt-cost-icon">
                            💧
                        </span>


                        <div>

                            <div class="prompt-cost-label">
                                WATER
                            </div>


                            <div class="prompt-cost-number">

                                ${cost.water.toFixed(2)}
                                mL

                            </div>

                        </div>

                    </div>


                </div>


                <div class="prompt-cost-note">

                    ESTIMATED
                    ${
                        cost.totalTokens
                        ?
                        ` · ${cost.totalTokens} TOKENS`
                        :
                        ""
                    }

                </div>

            </div>

            `
            :
            ""
        }

    `;


    wrapper
        .querySelector(
            ".ai-response-text"
        )
        .textContent = text;


    conversation.appendChild(
        wrapper
    );


    scrollConversation();

}


/* =========================================================
   TYPING INDICATOR
   ========================================================= */

function showTyping() {

    const wrapper =
        document.createElement("div");


    wrapper.id =
        "typingMessage";


    wrapper.className =
        "ai-message";


    wrapper.innerHTML = `

        <span class="message-label">
            AI
        </span>


        <div class="typing">

            <span></span>
            <span></span>
            <span></span>

        </div>

    `;


    conversation.appendChild(
        wrapper
    );


    scrollConversation();

}


/* =========================================================
   REMOVE TYPING
   ========================================================= */

function removeTyping() {

    const typing =
        document.getElementById(
            "typingMessage"
        );


    if (typing) {

        typing.remove();

    }

}


/* =========================================================
   COST CALCULATION
   ========================================================= */

function calculateEnvironmentalCost(
    usage = null
) {

    /*
       If Gemini did not return usage data,
       use the published median reference.
    */

    if (!usage) {

        const energy =
            ENERGY_PER_PROMPT;

        const heat =
            energy *
            HEAT_PER_WH;

        const water =
            WATER_PER_PROMPT;


        return {

            energy:
                energy,

            heat:
                heat,

            water:
                water,

            totalTokens:
                null

        };

    }


    /* -----------------------------------------
       ACTUAL TOKEN USAGE
       ----------------------------------------- */

    const promptTokens =
        Number(
            usage.promptTokens
        ) || 0;


    const outputTokens =
        Number(
            usage.outputTokens
        ) || 0;


    const thoughtTokens =
        Number(
            usage.thoughtTokens
        ) || 0;


    const totalTokens =
        Number(
            usage.totalTokens
        ) ||
        (
            promptTokens +
            outputTokens +
            thoughtTokens
        );


    /*
       Token workload is used only as a
       relative complexity indicator.

       We do NOT claim:

       1 token = X Wh

       because that would be scientifically
       misleading.
    */

    let multiplier =
        totalTokens /
        REFERENCE_TOTAL_TOKENS;


    /*
       Keep the visual estimate within
       sensible limits.
    */

    multiplier =
        Math.max(
            MIN_COST_MULTIPLIER,
            Math.min(
                MAX_COST_MULTIPLIER,
                multiplier
            )
        );


    const energy =
        ENERGY_PER_PROMPT *
        multiplier;


    const heat =
        energy *
        HEAT_PER_WH;


    const water =
        WATER_PER_PROMPT *
        multiplier;


    return {

        energy:
            energy,

        heat:
            heat,

        water:
            water,

        totalTokens:
            totalTokens

    };

}


/* =========================================================
   UPDATE SESSION TOTAL
   ========================================================= */

function updateCost(cost) {

    promptCount++;


    totalEnergy +=
        cost.energy;


    totalHeat +=
        cost.heat;


    totalWater +=
        cost.water;


    promptCounter.textContent =
        String(promptCount)
            .padStart(2, "0");


    animateNumber(

        energyValue,

        totalEnergy,

        2,

        " Wh"

    );


    animateNumber(

        heatValue,

        totalHeat,

        2,

        " kJ"

    );


    animateNumber(

        waterValue,

        totalWater,

        2,

        " mL"

    );


    /* -----------------------------------------
       SESSION COMPLETE MESSAGE
       ----------------------------------------- */

    if (
        sessionLimitReached()
    ) {

        setTimeout(

            function () {

                addAIMessage(

                    "SESSION COMPLETE — You've reached the 20-prompt limit."

                );

            },

            400

        );

    }

}


/* =========================================================
   NUMBER ANIMATION
   ========================================================= */

function animateNumber(

    element,

    target,

    decimals,

    suffix

) {

    const start =
        parseFloat(

            element.dataset.value ||
            0

        );


    const duration =
        500;


    const startTime =
        performance.now();


    function animate(currentTime) {

        const progress =
            Math.min(

                (

                    currentTime -
                    startTime

                ) / duration,

                1

            );


        const eased =
            1 -
            Math.pow(

                1 -
                progress,

                3

            );


        const value =
            start +

            (

                target -
                start

            ) *

            eased;


        element.textContent =
            value.toFixed(
                decimals
            ) +
            suffix;


        if (
            progress <
            1
        ) {

            requestAnimationFrame(
                animate
            );

        }

    }


    element.dataset.value =
        target;


    requestAnimationFrame(
        animate
    );

}


/* =========================================================
   CHAT SCROLL
   ========================================================= */

function scrollConversation() {

    const chatArea =
        document.querySelector(
            ".chat-area"
        );


    setTimeout(

        function () {

            chatArea.scrollTop =
                chatArea.scrollHeight;

        },

        30

    );

}


/* =========================================================
   METHODOLOGY
   ========================================================= */

methodButton.addEventListener(

    "click",

    function () {

        methodology.classList.remove(
            "hidden"
        );

    }

);


closeMethod.addEventListener(

    "click",

    function () {

        methodology.classList.add(
            "hidden"
        );

    }

);


/* =========================================================
   ABOUT THIS POSTER
   ========================================================= */

aboutButton.addEventListener(

    "click",

    function () {

        aboutPoster.classList.remove(
            "hidden"
        );

    }

);


closeAbout.addEventListener(

    "click",

    function () {

        aboutPoster.classList.add(
            "hidden"
        );

    }

);


/* =========================================================
   ESCAPE KEY
   ========================================================= */

document.addEventListener(

    "keydown",

    function (event) {

        if (
            event.key === "Escape"
        ) {

            methodology.classList.add(
                "hidden"
            );


            aboutPoster.classList.add(
                "hidden"
            );

        }

    }

);


/* =========================================================
   INITIAL FOCUS
   ========================================================= */

input.focus();